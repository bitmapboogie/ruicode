<?php


//remove the sidebar
function removeSidebar(){
	return false;	
}
add_filter('thematic_sidebar', 'removeSidebar');

//remove post footer
function removePostFooter(){
	return false;	
}
add_filter('thematic_postfooter', 'removePostFooter');


//remove post metadata
function removePostMetaData(){
	return false;	
}
add_filter('thematic_postheader_postmeta', 'removePostMetaData');

//tell wordpress that we want to support thumbnails
add_theme_support( 'post-thumbnails' );
set_post_thumbnail_size( 620, 99999, false );

//add link to a thumbnail
add_filter( 'post_thumbnail_html', 'my_post_image_html', 10, 3 );

function my_post_image_html( $html, $post_id, $post_image_id ) {

	$html = '<a href="' . get_permalink( $post_id ) . '" title="' . esc_attr( get_post_field( 'post_title', $post_id ) ) . '">' . $html . '</a>';

	return $html;
}

//index loop with thumbnails
function index_with_thumbs() {
	global $options;
	foreach ($options as $value) {
    	if (get_option( $value['id'] ) === FALSE) { $$value['id'] = $value['std']; }
    	else { $$value['id'] = get_option( $value['id'] ); }
    }
		/* Count the number of posts so we can insert a widgetized area */ $count = 1;
		while ( have_posts() ) : the_post() ?>

			<div id="post-<?php the_ID() ?>" class="<?php thematic_post_class() ?>">
    			<?php thematic_postheader(); ?>
    			
				<div class="entry-content">
				
				<?php
   				if(has_post_thumbnail()){

					the_post_thumbnail(array(620, 99999));

   				}
   				?>
				
				<?php thematic_content(); ?>

				<?php wp_link_pages('before=<div class="page-link">' .__('Pages:', 'thematic') . '&after=</div>') ?>
				</div>
				<?php thematic_postfooter(); ?>
			</div><!-- .post -->

				<?php comments_template();

				if ($count==$thm_insert_position) {
						get_sidebar('index-insert');
				}
				$count = $count + 1;
		endwhile;
}

add_action('thematic_indexloop', 'index_with_thumbs');
//the original action hook from thematic theme is disabled in index.php

?>