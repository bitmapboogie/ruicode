<?php
//empty comments file = no comments :)


?>